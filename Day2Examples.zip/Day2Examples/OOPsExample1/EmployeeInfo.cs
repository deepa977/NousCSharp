﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsExample1
{
    class EmployeeInfo:PersonInfo
    {
        int empid;
        string dept;
        string desg;
        decimal salary;
        public override void GetData()
        {
            base.GetData();
            Console.WriteLine("Enter emp id:");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Department:");
            dept = Console.ReadLine();
            Console.WriteLine("Enter emp designation:");
            desg = Console.ReadLine();
            Console.WriteLine("Enter emp salary:");
            salary = decimal.Parse(Console.ReadLine());
        }
        public override void ShowData()
        {
            base.ShowData();
            Console.WriteLine("Emp Id:" + empid);
            Console.WriteLine("Department:" + dept);
            Console.WriteLine("Designation:" + desg);
            Console.WriteLine("Salary:" + salary);
        }
        //constructor chaining 
        public EmployeeInfo():base()
        {
            empid = 999;
            dept = "Service Dept";
            desg = "Service Desg";
            salary = 8600;
        }
        public EmployeeInfo(string name,string add,char gen, long mno,string email,byte age,int eid,string dept,string desg,decimal sal):base(name,add,gen,mno,email,age)
        {
            empid = eid;
            this.dept = dept;
            this.desg = desg;
            salary = sal;
        }

    }
}
