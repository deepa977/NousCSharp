﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsExample1
{
    class StudentInfo:PersonInfo
    {
        int usn;
        string course;
        string branch;
        int sem;
        decimal aggrmarks;
        public override void GetData()
        {
            base.GetData();
            Console.WriteLine("Enter USN:");
            usn = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Department:");
           branch = Console.ReadLine();
            Console.WriteLine("Enter Branch:");
            branch = Console.ReadLine();
            Console.WriteLine("Enter Aggregate:");
            aggrmarks= decimal.Parse(Console.ReadLine());
        }
        public override void ShowData()
        {
            base.ShowData();
            Console.WriteLine("USN:" + usn);
            Console.WriteLine("Department:" + branch);
            Console.WriteLine("Branch:" + branch);
            Console.WriteLine("Aggregate:" +aggrmarks);
        }
        public StudentInfo(string name, string add, char gen, long mno, string email, byte age, int usn, string course, string branch, int sem, decimal agg) : base(name, add, gen, mno, email, age)
        {
            this.usn = usn;
            this.branch = branch;
            this.course = course;
            this.sem = sem;
            aggrmarks = agg;
        }
        public StudentInfo():base()
        {
            usn = 9;
            branch = "CS";
            course = "Btech";
            sem = 1;
            aggrmarks = 70;
        }

    }
}
