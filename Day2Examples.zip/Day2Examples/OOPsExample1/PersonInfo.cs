﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsExample1
{
    /*sealed*/ class PersonInfo
    {
        protected string name;
        protected string address;
        protected char gender;
        protected long mobno;
        protected string emailid;
        protected byte age;

       
            public virtual void GetData()
            {
                Console.WriteLine("Enter name:");
                name = Console.ReadLine();
                Console.WriteLine("Enter address:");
                address = Console.ReadLine();
                Console.WriteLine("Enter gender:");
                gender = char.Parse(Console.ReadLine());
                Console.WriteLine("Enter mobile number:");
                mobno = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter email id:");
                emailid = Console.ReadLine();
                Console.WriteLine("Enter age:");
                age = byte.Parse(Console.ReadLine());
            }
            public virtual void ShowData()
            {
                Console.WriteLine("Name:" + name);
                Console.WriteLine("Address:" + address);
                Console.WriteLine("Gender:" + gender);
                Console.WriteLine("Mobile Number:" + mobno);
                Console.WriteLine("Email ID:" + emailid);
                Console.WriteLine("Age:" + age);
            }
        //parameterized constructor
        public PersonInfo(string name, string add, char gen,long mno,string email,byte age)
        {
            //parameter variables are called local variables
            //class variables are called instance variables.memory is allocated to these variables only when we create object of a class
            //class variable and parameter variable will have the same name- then use "this" before the class variable
            this.name = name;
            address = add;
            gender = gen;
            mobno = mno;
            emailid = email;
            this.age = age;

        }
        public PersonInfo()
        {
            name = "Bindu";
            address = "Mysore";
            gender = 'F';
            mobno = 9999999999;
            emailid = "default@gmail.com";
            age = 23;
        }
        public PersonInfo(string name, string add, char gen)
        {
            this.name = name;
            address = add;
            gender = gen;

        }

        ~PersonInfo()
        {
            GC.Collect();
            Console.WriteLine("Object Destroyed.....");
        }
        }
       
    }

