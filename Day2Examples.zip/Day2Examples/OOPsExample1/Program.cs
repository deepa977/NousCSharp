﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsExample1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* PersonInfo sridhar = new PersonInfo();
             //new keyword is used to allocate memory for everything we have defined in personinfo class
             sridhar.GetData();
             sridhar.ShowData();
             PersonInfo bindu = new PersonInfo();
             bindu.ShowData();
             PersonInfo kumar = new PersonInfo("KumarVel", "Chennai", 'M', 2443434231, "kumar@gmail.com", 26);
             kumar.ShowData();
             PersonInfo deepa = new PersonInfo("Deepa","Kengeri",'F');
             deepa.ShowData();*/


            //in the concept of inheritance parent class can create object of child class
            PersonInfo pinfo = new StudentInfo();
            pinfo.ShowData();

            EmployeeInfo einfo = new EmployeeInfo();
            einfo.ShowData();

            pinfo = new StudentInfo("Keerthi", "hubli", 'f', 232423423, "k@gmailcom", 32, 771, "MCA", "CS", 4, 78.90M);
            pinfo.ShowData();


            einfo = new EmployeeInfo("James", "pune", 'm', 24234234, "james@gmail.com", 35, 9000, "Research", "Consultant", 424234);
            einfo.ShowData();

            StudentInfo newstudent = new StudentInfo();
            newstudent.GetData();
            newstudent.ShowData();

            EmployeeInfo empnew = new EmployeeInfo();
            empnew.GetData();
            empnew.ShowData();


            


        }
    }
}
