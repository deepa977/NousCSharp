﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class Addition
    {
        //methods are overloaded based on thier parameters. not on thier return type
        public void Add()
        {
            int a, b, c;
            a = 10;
            b = 20;
            c = a + b;
            Console.WriteLine("C:" + c);
        }
        public int Add(int x,int y)
        {
            return (x + y);
        }

        public string Add(string fname,string lname)
        {
            return "Fullname is" + (fname + lname);
        }

        public void Add(int x,int y,int z)
        {
            Console.WriteLine("x :" + x);
            Console.WriteLine("ÿ:" + y);
            Console.WriteLine("Z:" + z);

        }

    }
}
