﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Addition a = new Addition();
            Console.WriteLine(a.Add(12, 14));
            Console.WriteLine(a.Add("Tom", "Jerry"));
            a.Add();
            a.Add(12, 13, 45);
            //normal way 
            DifferentTypes.EmpInfo(123, "Hema", "Äccounts", 56000);
            Console.WriteLine();
            //change the order by using named parameter
            DifferentTypes.EmpInfo(salary: 25000, ename: "James", empid: 900, dept: "Admin");
            Console.WriteLine();
            //ignore the optional parameter
            DifferentTypes.EmpInfo(empid: 12200, ename: "Komal");
            Console.WriteLine();
            DifferentTypes.StudentMarks(1, "Rachana", 78, 90, 45, 67, 89, 37);
            DifferentTypes.StudentMarks(2, "Geetha", 34, 56);
            DifferentTypes.StudentMarks(3, "neil", 67, 45, 39, 40);

        }
    }
}
