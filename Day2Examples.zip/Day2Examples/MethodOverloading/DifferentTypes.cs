﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class DifferentTypes
    {
        public static void EmpInfo(int empid, string ename,string dept="IT",decimal salary=10000M)
        {
            //empid and ename are required parameter
            //dept and salary are optional parameter
            //optional parameters should be in the end of  the list of parameter
            Console.WriteLine("Ëmpid:" + empid);
            Console.WriteLine("Name:" + ename);
            Console.WriteLine("Dept:" + dept);
            Console.WriteLine("Sal:" + salary);
        }

        public static void StudentMarks(int rollno, string name,params double []marks)
        {
            Console.WriteLine("RollNo:" + rollno);
            Console.WriteLine("Name:" + name);
            foreach (double m in marks)
                Console.WriteLine(m);

            Console.WriteLine();

        }
    }
}
