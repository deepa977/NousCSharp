﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Entity_Layer;

namespace DataAccessLayer
{
    public class PersonInfoDAL
    {
        SqlConnection con = null;
        SqlCommand com = null;
        SqlDataReader r = null;
        //to read the connection parameters from web.cofig
        string connstr = System.Configuration.ConfigurationManager.ConnectionStrings["MyConn"].ToString();
        public bool InsertPersonInfo(PersonInfoEntity entity)
        {
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "insert into PersonInfo values(@name,@em,@pwd,@add,@mno,@gen,@age)";
                com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@name", entity.Name);
                com.Parameters.AddWithValue("@em", entity.Email);
                com.Parameters.AddWithValue("@pwd", entity.Password);
                com.Parameters.AddWithValue("@add", entity.Address);
                com.Parameters.AddWithValue("@mno", entity.MobNo);
                com.Parameters.AddWithValue("@gen", entity.Gender);
                com.Parameters.AddWithValue("@age", entity.Age);
                var res = com.ExecuteNonQuery();
                if (res > 0)
                    return true;
            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return false;
        }
        public List<PersonInfoEntity> SelectData()
        {
            List<PersonInfoEntity> lstperson = new List<PersonInfoEntity>();
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "select * from personinfo";
                com = new SqlCommand(query, con);
                r = com.ExecuteReader();
                while (r.Read())
                {
                    PersonInfoEntity entity = new PersonInfoEntity(); //new row of data
                    entity.Name = r[0].ToString();
                    entity.Email = r[1].ToString();
                    entity.Password = r[2].ToString();
                    entity.Address = r[3].ToString();
                    entity.MobNo = Convert.ToInt64(r[4]);
                    entity.Gender = r[5].ToString();
                    entity.Age = Convert.ToInt32(r[6]);
                    lstperson.Add(entity);
                }
            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                r.Close();
                con.Close();
            }
            return lstperson;
        }



        public string Login(string email, string pass)
        {
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "select * from personinfo where emailid=@em and password=@pwd";
                com = new SqlCommand(query, con);
                com.Parameters.AddWithValue("@em", email);
                com.Parameters.AddWithValue("@pwd", pass);
                r = com.ExecuteReader();
                if(r.Read())
                
                    return "Valid user info";
                    else
                        return "Invalid User Info";
                
           }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return string.Empty;
        }

        public bool DeletePersonInfo(string em)
        {
            try
            {
                //how to call a stored procedure
                con = new SqlConnection(connstr);
                con.Open();
                com = new SqlCommand("sp_DeletePersonInfo", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@em", em);
                var res = com.ExecuteNonQuery();
                if (res > 0)
                    return true;
           }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return false;
        }

    }
}
