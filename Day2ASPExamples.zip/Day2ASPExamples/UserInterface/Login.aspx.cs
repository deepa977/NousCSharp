﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
namespace UserInterface
{
    public partial class Login : System.Web.UI.Page
    {
        PersonInfoDAL dal = new PersonInfoDAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            try
            {
                string email = Login1.UserName;
                string pwd = Login1.Password;
                var res = dal.Login(email, pwd);
                Login1.FailureText = res;
                if (res == "Valid user info")
                    Response.Redirect("DeletePersonInfo.aspx");//syntax to redirect from one page to another page
            }
            catch(Exception ex)
            {
                Login1.FailureText = ex.Message;
            }
        }
    }
}