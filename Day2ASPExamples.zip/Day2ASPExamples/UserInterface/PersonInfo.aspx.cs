﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity_Layer;
using DataAccessLayer;
namespace UserInterface
{
    public partial class PersonInfo : System.Web.UI.Page
    {
        PersonInfoDAL dal = new PersonInfoDAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //UI controls are having page scope
            string name = txtName.Text;
            string address = txtAddress.Text;
            string passowrd = txtPassword.Text;
            string email = txtEmail.Text;
            long mob = long.Parse(txtNumber.Text);
            int age = int.Parse(txtAge.Text);
                        Label1.Text = name + "," + address + "," + passowrd + "," + email + "," + mob + "," + gender + "," + age + ",";
            PersonInfoEntity entity = new PersonInfoEntity();
            entity.Name = name;
            entity.Email = email;
            entity.Password = passowrd;
            entity.Address = address;
            entity.MobNo = mob;
            entity.Gender = gender;
            entity.Age = age;
            try
            {
                var res = dal.InsertPersonInfo(entity);
                if (res)
                    Label1.Text = "Data Inserted successfully....";
            }
            catch(Exception  ex)
                {
                Label1.Text = ex.Message;
            }
        }
        
        string gender = " ";

        protected void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            gender = rbMale.Text;
        }

        protected void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = rbFemale.Text;
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                var res = dal.SelectData();
                GridView1.DataSource = res;
                GridView1.DataBind();

            }
            catch(Exception ex)
            {
                Label1.Text = ex.Message;
            }
        }
    }
}