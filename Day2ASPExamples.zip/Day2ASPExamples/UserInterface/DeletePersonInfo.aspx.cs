﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
namespace UserInterface
{
    public partial class DeletePersonInfo : System.Web.UI.Page
    {
        PersonInfoDAL dal = new PersonInfoDAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                var res = dal.DeletePersonInfo(txtEmail.Text);
                if (res)
                    Response.Write("Data Deleted.....");
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);//write directly to browser window
            }
        }
    }
}