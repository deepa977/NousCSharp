﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExample
{
    class Program
    {
        //declare a delegate
        //method signature and delegate signature should be same
        public delegate void CalcDelegate(int x, int y);
        static void Main(string[] args)
        {
            Calculator c = new Calculator();
            CalcDelegate cd = c.Add;
            cd += c.Sub;
            cd += c.Mul;
            cd += c.Div;

            cd(10, 10);
            cd -= c.Sub;
            cd -= c.Div;


            cd(12, 70);
        }
    }
}
