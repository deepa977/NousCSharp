﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, CountryInfo> country = new Dictionary<string, CountryInfo>();
            //string ->key , CountryInfo ->value
            country.Add("IN", new CountryInfo { CountryName = "India", Capital = "New Delhi", Currency = "Rs" });
            country.Add("US", new CountryInfo { CountryName = "America", Capital = "Washington DC", Currency = "$" });
            country.Add("SL", new CountryInfo { CountryName = "SriLanka", Capital = "Colombo", Currency = "Rs" });
            foreach(KeyValuePair<string,CountryInfo> kvp in country)
            {
                Console.WriteLine(kvp.Key);
                Console.WriteLine(kvp.Value.CountryName + " " + kvp.Value.Capital + " " + kvp.Value.Currency);
                Console.WriteLine("*************");
            }
        }
    }
}
