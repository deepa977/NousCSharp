﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefOutExample
{
    class Addition
    {
        public void SumRef(ref int x,ref int y)
        {
            Console.WriteLine("Add:" + (x + y));
        }
        public void SumOut(out int x,out int y)
        {
            x = 100;
            y = 200;
            Console.WriteLine("Add:" + (x + y));
        }
    }
}
