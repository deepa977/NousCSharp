﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefOutExample
{
    class SwapData<T>
    {
        public void swap(ref T a,ref T b)
        {
            T tmp = a;
            a = b;
            b = tmp;

        }
    }
}
