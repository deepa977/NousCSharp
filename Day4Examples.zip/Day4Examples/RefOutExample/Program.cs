﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefOutExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            num1 = 9;
            num2 = 7;
            Addition a = new Addition();
            a.SumRef(ref num1, ref num2);
            int i, j;
            a.SumOut(out i, out j);
            Console.WriteLine(i + " " + j);

            //generic
            char c = 'A';
            char d = 'M';
            Console.WriteLine("Before Swapping:" + c + " " + d);
            SwapData<char> obj = new SwapData<char>();
            obj.swap(ref c, ref d);
            Console.WriteLine("After Swapping:" + c + " " + d);

            //int , string swap try to do this
            string s1 = "sridhar";
            string s2 = "bhat";
            Console.WriteLine("Before swapping:" + s1 + " " + s2);
            SwapData<string> cc1 = new SwapData<string>();
            cc1.swap(ref s1, ref s2);
            Console.WriteLine("After swapping:" + s1 + " " + s2);


            int e = 1;
            int f = 2;
            Console.WriteLine("before swapping:" + e + " " + f);
            SwapData<int> obj1 = new SwapData<int>();
            obj1.swap(ref e, ref f);
            Console.WriteLine("After swappping:" + e + " " + f);
        }
    }
}
