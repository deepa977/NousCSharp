﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExample
{
    class OrderItems
    {
        double GrandTotal = 0;
        public void AddCart(List<ItemDetails> items)
        {
            char ans = 'y';
            do
            {
                ItemDetails newitem = new ItemDetails();
                Console.WriteLine("Enter Item Code");
                newitem.ItemCode = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Description");
                newitem.Description = Console.ReadLine();
                Console.WriteLine("Enter Price");
                newitem.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Qty");
                newitem.Qty = int.Parse(Console.ReadLine());
                newitem.Total = newitem.Price * newitem.Qty;
                Console.WriteLine("Continue(y/n)?");
                ans = char.Parse(Console.ReadLine());
                items.Add(newitem);
            } while (ans == 'y' || ans == 'Y');
        }
        public void ShowCart(List<ItemDetails> items)
        {
            GrandTotal = 0;
            Console.WriteLine("Count of items : " + items.Count);
            foreach(var i in items)
            {
                Console.WriteLine("item COde:" + i.ItemCode);
                Console.WriteLine("item Desc:" + i.Description);
                Console.WriteLine("item Price:" + i.Price);
                Console.WriteLine("item Qty:" + i.Qty);
                Console.WriteLine("item Total:" + i.Total);
                Console.WriteLine("**********");
                GrandTotal += i.Total;
            }
            Console.WriteLine("Grand Total:" + GrandTotal);

        }

    }
}
