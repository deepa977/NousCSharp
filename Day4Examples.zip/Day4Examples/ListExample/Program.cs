﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExample
{
    class Program
    {
        static void Main(string[] args)
        {
            List<ItemDetails> items = new List<ItemDetails>();
            OrderItems order = new OrderItems();
            order.AddCart(items);
            order.ShowCart(items);
            //insert a new item inbetween
  ItemDetails insertnew=new ItemDetails { ItemCode = 100, Description = "Mangoes", Price = 120, Qty = 2 ,Total=240};
            items.Insert(1, insertnew);
            Console.WriteLine("After Insert:");
            order.ShowCart(items);
            items.RemoveAt(0);
            Console.WriteLine("After Remove:");
            order.ShowCart(items);

        }
    }
}
