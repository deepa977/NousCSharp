﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 23, 33, 43, 53, 63 };
            string[] cities = new string[5];
            cities[0] = "Bangalore";
            cities[1] = "Mysore";
            cities[2] = "Hubli";
            cities[3] = "Mangalore";
            cities[4] = "Bidar";
            int[,] matrix = new int[2, 3];
            Console.WriteLine("Ënter Matrix element");
            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 3; j++)
                    matrix[i, j] = int.Parse(Console.ReadLine());

            foreach (var a in arr)
                Console.WriteLine(a);

            Console.WriteLine();
            foreach (var c in cities)
                Console.WriteLine(c);

            Console.WriteLine();

            foreach (var m in matrix)
                Console.WriteLine(m);



            





        }
    }
}
