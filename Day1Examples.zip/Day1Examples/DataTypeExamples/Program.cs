﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypeExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            byte age;
            string name;
            char gender;
            decimal salary;
            bool cab;
            DateTime doj;
            long mno;
            string emailid;
            Console.WriteLine("Enter Age");
            bool result = byte.TryParse(Console.ReadLine(), out age);
            if (result == false)
            {
                Console.WriteLine("Enter only numbers for age");
                return;
            }
            Console.WriteLine("Enter Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Gender");
            result = char.TryParse(Console.ReadLine(),out gender);
            if(result==false)
            {
                Console.WriteLine("gender has to be M or F");
                return;
                    
            }
            Console.WriteLine("Enter Salary");
            salary = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter Cab(true/false)");
            cab = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter DOJ");
            doj = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter MobNo");
            mno = long.Parse(Console.ReadLine());
            Console.WriteLine("Enter EmailID");
            emailid = Console.ReadLine();
            Console.WriteLine("Age:" + age);
            Console.WriteLine("Name:" + name + "\nGender:" + gender+"\n");
            Console.WriteLine("Salary:{0}\nCab:{1}\nDOJ:{2}\n", salary, cab, doj);
            Console.WriteLine("{0}\n{1}\n", mno, emailid);



        }
    }
}
