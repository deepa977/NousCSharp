﻿using System; //default namespace. using namespace                                     //import java.lang.*; import package
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram  //java-> package name
                        //package com.examples.FirstExample
                        //it is used to group classes under a particular name
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("My first C# Program"); //System.out.println("My First Java program");

            //build and execute the program ctrl+fn+f5

        }
    }
}
