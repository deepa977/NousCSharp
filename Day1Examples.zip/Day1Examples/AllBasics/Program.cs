﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            int id;
            string name;
            string dept;
            decimal salary=0.0M;
            char ans = 'y';
            do
            {
                Console.WriteLine("Enter ID");
                id = int.Parse(Console.ReadLine());
                if(id<=0)
                {
                    Console.WriteLine("ID cannot be zero or negative");
                    return;
                }
                Console.WriteLine("Enter Name");
                name = Console.ReadLine();
                if(string.IsNullOrEmpty(name)||string.IsNullOrWhiteSpace(name))
                {
                    Console.WriteLine("name cannot be null or blank");
                    return;
                }
                Console.WriteLine("Enter Dept(IT,HR,Admin,Accts)");
                dept = Console.ReadLine();
                switch (dept.ToUpper())
                {
                    case "IT":salary = 40000;
                        break;
                    case "HR":salary = 35000;
                        break;
                    case "ADMIN":salary = 30000;
                        break;
                    case "ACCTS":salary = 25000;
                        break;
                    default:salary = 10000;
                        break;
                }
                Console.WriteLine("ID:" + id);
                Console.WriteLine("Name:" + name);
                Console.WriteLine("Dept:" + dept);
                Console.WriteLine("Salary:" + salary);
                Console.WriteLine("Continue(y/n)?");
                ans = char.Parse(Console.ReadLine());

            } while (ans == 'y' || ans == 'Y');
            //current date and time
            Console.WriteLine("Current Date and Time:" + DateTime.Now);
            DateTime doj = DateTime.Parse("19-09-2002");
            int m = doj.Month;
            int y = doj.Year;
            int d = doj.Day;
            Console.WriteLine("m" + m);
            Console.WriteLine("y" + y);
            Console.WriteLine("d:" + d);

            DateTime dob = DateTime.Parse("24-08-2003");
            DateTime currdate = DateTime.Now;
            TimeSpan totalyears = currdate.Subtract(dob);

            Console.WriteLine("No of Years:" + (totalyears.TotalDays)/365);

            Console.WriteLine(currdate.ToShortDateString());
            Console.WriteLine(currdate.ToLongDateString());
        }
    }
}
